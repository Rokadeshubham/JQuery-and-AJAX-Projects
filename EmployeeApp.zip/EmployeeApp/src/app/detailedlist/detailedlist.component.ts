import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-detailedlist',
  templateUrl: './detailedlist.component.html',
  styleUrls: []
})
export class DetailedlistComponent {

  constructor(private _service:EmployeeService) { }
singleEmployeeInfo;
  
getInformationById(Employeeid){
    this._service.getInformation(Employeeid).subscribe(s=>this.singleEmployeeInfo=s);
  }

}
