import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { FormGroup } from '@angular/forms';
import { FormBuilder,Validators } from '@angular/forms';
import { Employee } from '../employee';

@Component({
  selector: 'app-employeelist',
  templateUrl: './employeelist.component.html',
  styleUrls: []
})
export class EmployeelistComponent  {
Employees = [];
updateForm : FormGroup;
  constructor(private formbuilder:FormBuilder,private _service:EmployeeService) { 
    this._service.getInfoes().subscribe(s=>this.Employees=s);
  }

  Delete(e){
    this._service.deleteEmployee(e);
  }
//Update
  ngOnInit() {
    this.updateForm = this.formbuilder.group({
      Employeeid:['',[Validators.required]],
      Employeename:['',[Validators.required,Validators.minLength(3)]],
      Salary:['',[Validators.required,Validators.min(10000)]],
      Dateofbirth:['',[Validators.required]],
      City:['',[Validators.required]]
    })
  }

  Edit(e){
    this.updateForm.setValue(e);
  }
  onFormUpdate(){
    let employee = this.updateForm.value;
    this.update(employee);
    this.updateForm.reset();
  }
  update(employee:Employee){
    this._service.updateEmployee(employee);
  }
  //Update


  //Employee Details Info
  singleEmployeeInfo;
  Details(e){
    this._service.getInformation(e).subscribe(s=>this.singleEmployeeInfo=s);
  }
 
}
