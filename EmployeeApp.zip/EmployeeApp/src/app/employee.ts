export interface Employee {
    Employeeid:number,
    Employeename:String,
    Salary:number,
    Dateofbirth:Date,
    City:String
}
