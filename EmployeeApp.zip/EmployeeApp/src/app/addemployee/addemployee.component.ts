import { Component, OnInit } from '@angular/core';
import {FormsModule, FormGroup, Validators} from '@angular/forms'
import {FormBuilder} from '@angular/forms'
import { EmployeeService } from '../employee.service';
import { Employee } from '../employee';
@Component({
  selector: 'app-addemployee',
  templateUrl: './addemployee.component.html',
  styleUrls: []
})
export class AddemployeeComponent{

  City = ["Pune","Mumbai"];
  datsaved : true;
  employeeForm:FormGroup;

  constructor(private formbuilder:FormBuilder,private _service:EmployeeService) { }

  ngOnInit() {
    this.employeeForm = this.formbuilder.group({
      Employeeid:['',[Validators.required]],
      Employeename:['',[Validators.required,Validators.minLength(3)]],
      Salary:['',[Validators.required,Validators.min(10000)]],
      Dateofbirth:['',[Validators.required]],
      City:['',[Validators.required]]
    })
  }
  create(employee:Employee){
    this._service.CreateEmployee(employee).subscribe(employee=>{this.datsaved=true})
  }
  onFormSubmit(){
    let employee = this.employeeForm.value;
    this.create(employee);
    this.employeeForm.reset();
  }

  

}
