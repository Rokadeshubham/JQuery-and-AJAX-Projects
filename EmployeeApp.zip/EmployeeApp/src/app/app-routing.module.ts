import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployeelistComponent } from './employeelist/employeelist.component';
import { AddemployeeComponent } from './addemployee/addemployee.component';
import { DetailedlistComponent } from './detailedlist/detailedlist.component';

const routes: Routes = [
  {path:"AllEmployees",component:EmployeelistComponent},
  {path:"AddEmployee",component:AddemployeeComponent},
  {path:"Details",component:DetailedlistComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
