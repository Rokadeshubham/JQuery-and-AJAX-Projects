import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {Employee} from './employee'
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  url:string = "http://localhost:63092/api/Employee";

  constructor(private _http:HttpClient) {
    
  }
  CreateEmployee(employee:Employee):Observable<Employee>{
    let httpHeaders = new HttpHeaders()
    .set('Content-Type','application/json');
    let options = {
        headers :httpHeaders
    };
    return this._http.post<Employee>(this.url,employee,options);
  }

  getInformation(id:number):Observable<any>{
    return this._http.get<any>("http://localhost:63092/api/Employee/"+id);
  }


  getInfoes():Observable<any>{
   return this._http.get<any>(this.url);
  }
  deleteEmployee(id){
    let headers = new HttpHeaders()
    .set('Content-Type','application/json');
   this._http.delete("http://localhost:63092/api/Employee/"+id,{headers} ).toPromise();
  }
  updateEmployee(employee:Employee){
    let httpHeaders = new HttpHeaders()
    .set('Content-Type','application/json');
    let options = {
        headers :httpHeaders
    };
    this._http.put<Employee>(this.url,employee,options).toPromise();
  }
  
}
