﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using AngularApi.Models;
using System.Web.Http.Description;

namespace AngularApi.Controllers
{
    public class EmployeeController : ApiController
    {

        public IEnumerable<Employee> Get()
        {
            using (EmployeeEntities entities = new EmployeeEntities())
            {
                return entities.Employees.ToList();
            }
        }
      
       
        public Employee Get(int id)
        {
            using (EmployeeEntities entities = new EmployeeEntities())
            {
                return entities.Employees.Where(e=>e.Employeeid == id).FirstOrDefault();
            }
        }


        
        //public IHttpActionResult GetEmployee(int id)
        //{
        //    using (EmployeeEntities entities = new EmployeeEntities())
        //    {
        //        Employee employee = entities.Employees.Find(id);
        //        if (employee == null)
        //        {
        //            return NotFound();
        //        }

        //        return Ok(employee);
        //    }
            
        //}

        [HttpPost]
        public void Post([FromBody]Employee employee)
        {
            using (EmployeeEntities entities = new EmployeeEntities())
            {
                entities.Employees.Add(employee);
                entities.SaveChanges();
            }
        }

        [HttpDelete]
        public void Delete( int id)
        {
            using (EmployeeEntities entities = new EmployeeEntities())
            {
                var employee = entities.Employees.FirstOrDefault(e => e.Employeeid == id);
                entities.Employees.Remove(employee);
                entities.SaveChanges();
            }
        }

        [HttpPut]
        public void Put([FromBody]Employee employee)
        {
            using (EmployeeEntities entities = new EmployeeEntities())
            {
                var emp = entities.Employees.FirstOrDefault(e => e.Employeeid == employee.Employeeid);
                emp.Employeename = employee.Employeename;
                emp.Salary = employee.Salary;
                emp.City = employee.City;
                emp.Dateofbirth = employee.Dateofbirth;
                entities.SaveChanges();
            }
        }




    }
}
